    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Contact Us</h3>
                    <ul class="contact-info">
                        <li><i class="fas fa-envelope"></i> kantinku@sekolah.com</li>
                        <li><i class="fas fa-phone"></i> (021) 1234-5678</li>
                        <li><i class="fas fa-map-marker-alt"></i> Jl. Sekolah No. 123, Jakarta</li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> KantinKu. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="<?php echo $base_url; ?>assets/js/script.js"></script>
</body>
</html>